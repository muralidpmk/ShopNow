from django.shortcuts import render, redirect

from store.models.customer import Customer
from django.contrib.auth.hashers import make_password
from django.views import View


class Signup(View):
    def get(self, request):
        return render(request, 'signup.html')

    def post(self, request):
        postData = request.POST
        first_name = postData.get('firstname')
        last_name = postData.get('lastname')
        phone = postData.get('phone')
        email = postData.get('email')
        password = postData.get('password')
        # validation
        value = {
            'first_name': first_name,
            'last_name': last_name,
            'phone': phone,
            'email': email,
            'password': password,
        }

        error_message = None
        customer = Customer(first_name=first_name,
                            last_name=last_name,
                            phone=phone,
                            email=email,
                            password=password)

        error_message = self.validateCustomer(customer)

        if not error_message:
            print(first_name, last_name, phone, email, password)
            customer.password = make_password(customer.password)
            print(customer.password)
            customer.register()
            return redirect('login')

        else:
            data = {
                'error': error_message,
                'values': value
            }
            return render(request, 'signup.html', data)

    def validateCustomer(self, customer):
        error_message = None
        if (not customer.first_name):
            error_message = "First name required"
        elif len(customer.first_name) < 4:
            error_message = "first name must be 4 characters long"
        elif (not customer.last_name):
            error_message = "Last name required"
        elif len(customer.last_name) < 4:
            error_message = "last name must be 4 characters long"
        elif (not customer.phone):
            error_message = "Phone number required"
        elif len(customer.phone) < 10 and customer.phone > 10:
            error_message = "phone number must be of 10 digits "
        elif (not customer.password):
            error_message = "password required"
        elif len(customer.password) < 6:
            error_message = "password must be 6 characters long"
        elif len(customer.email) < 8:
            error_message = "Email must be 8 charaters log"
        elif customer.isExists():
            error_message = 'Email Address Already Registered....'
        return error_message
