from django.shortcuts import render, redirect
from store.models.customer import Customer
from django.contrib.auth.hashers import check_password
from django.views import View
from store.models.products import Product
from store.models.orders import Order
from store.models.category import Category


class Orders(View):
    def get(self,request):
        customer=request.session.get('customer')
        print(customer)
        orders=Order.get_orders_by_customer(customer)
        print(orders)
        return render(request,'orders.html',{'orders':orders})